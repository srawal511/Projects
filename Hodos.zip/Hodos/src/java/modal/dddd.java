/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modal;

import D.DriverDetails;
import D.Location;
import D.Login;
import D.RegCompanyDetail;
import com.google.gson.Gson;
import java.util.ArrayList;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import static java.lang.System.out;

/**
 *
 * @author KULDEEP
 */
@Path("user")
public class dddd {

    @Path("insert1")
    @GET
    public String insert(@QueryParam("uname") String name, @QueryParam("let") double let, @QueryParam("lng") double lng) {

        try {
            
            int i =Integer.parseInt(name);
            
            System.out.println("start");
            Session see = NewHibernateUtil.getSessionFactory().openSession();
            Transaction tr = see.beginTransaction();

            Criteria cr = see.createCriteria(DriverDetails.class);
            cr.add(Restrictions.eq("phone",i));
            ArrayList<DriverDetails> al = (ArrayList<DriverDetails>)cr.list();

            System.out.println("second ");

            DriverDetails m = al.get(0);
            Login l = m.getLid();

            System.out.println("third");
            
            Criteria cr1 = see.createCriteria(Location.class);
            cr1.add(Restrictions.eq("lid", l));
            ArrayList<Location> al1 = (ArrayList<Location>)cr1.list();
            System.out.println("fourth");
            
            if (al1.size() == 0) {
                System.out.println("inside if");
                Location t = new Location();
                t.setLat(let);
                t.setLong1(lng);
                t.setLid(l);
                see.save(t);
//          
            } else if (al.size() > 0) {
                System.out.println("inside else");
                Location t1 = al1.get(0);
                t1.setLat(let);
                t1.setLong1(lng);
                t1.setLid(l);
                see.update(t1);

            }

            tr.commit();
        } catch (Exception e) {
            out.print(e.getMessage());
        }
        
        String m = "success";
        String msg = new Gson().toJson(m);
        return msg;
    }
}
