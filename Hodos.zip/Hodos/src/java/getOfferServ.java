/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import D.CustomerDetail;
import D.DriverDetails;
import D.Offer;
import D.Login;
import D.RegCompanyDetail;
import D.ServiceDetail;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author KULDEEP
 */
public class getOfferServ extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       PrintWriter out = response.getWriter();
        try
        {
            Session se=NewHibernateUtil.getSessionFactory().openSession();
            Transaction t=se.beginTransaction();
            HttpSession  ss =  request.getSession();
            String email=ss.getAttribute("email").toString();
            String uname=ss.getAttribute("UNAME").toString();
            
            Criteria cr = se.createCriteria(D.Login.class);
            cr.add(Restrictions.eq("email", email));
            ArrayList<Login> AL = (ArrayList<Login>) cr.list();
            if (AL.isEmpty()) {
               String msg = "You did not Any Offer :create exciting offer to boost";
                ss.setAttribute("msg", msg);
                RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
                rd.forward(request, response);
            }
            else if (AL.size() >=0) 
            {
               String Role= AL.get(0).getRole();
                    if("Service".equals(Role) )
                    {
                        Criteria cr1 = se.createCriteria(D.ServiceDetail.class);
                        cr1.add(Restrictions.eq("name",uname ));
                        ArrayList<ServiceDetail> AL1 = (ArrayList<ServiceDetail>) cr1.list();
                        String CNAME=AL1.get(0).getCName();

                        //Now for feedback table
                        Criteria cr2 = se.createCriteria(D.Offer.class);
                        cr1.add(Restrictions.eq("cname",CNAME ));
                        ArrayList<Offer> AL2 = (ArrayList<Offer>) cr2.list();
                        ArrayList<String> fmsg =new ArrayList<String>();
                                for(int j=0;j<=AL2.size();j++)
                                {
                                String Date=AL2.get(j).getDate();
                                int Discount=AL2.get(j).getDiscount();
                                int Mil=AL2.get(j).getMileage();
                                int price =   AL2.get(j).getPrice();
                                String Fback= " Offer on "+Date+ " for discount of " + Discount+ " for mileage "+ Mil+ "at price "+ price;
                                fmsg.add(Fback);
                                }//hence msg obtained
                                ss.setAttribute("Feed", fmsg);
                        RequestDispatcher rs=request.getRequestDispatcher("/getAchvment");
                        rs.forward(request, response);
                        }
                        if("Company".equals(Role) )
                        {
//                        
                        Criteria cr2 = se.createCriteria(D.Offer.class);
                       
                        ArrayList<Offer> AL2 = (ArrayList<Offer>) cr2.list();
                        ArrayList<String> fmsg =new ArrayList<String>();
                              if(AL2!=null){  for(int j=0;j<AL2.size();j++)
                                {
                                String Date=AL2.get(j).getDate();
                                int Discount=AL2.get(j).getDiscount();
                                int Mil=AL2.get(j).getMileage();
                                int price =   AL2.get(j).getPrice();
                                String Fback= " Offer on "+Date+ " for discount of " + Discount+ " for mileage "+ Mil+ "at price "+ price;
                                fmsg.add(Fback);
                                }//hence msg obtained
                                ss.setAttribute("Feed", fmsg);
                              }
                              RequestDispatcher rs=request.getRequestDispatcher("/getAchvment");
                        rs.forward(request, response);
                        }

                        if("Customer".equals(Role) )
                    {
//                                                                                            Criteria cr1 = se.createCriteria(D.CustomerDetail.class);
//                                                                                            cr1.add(Restrictions.eq("name",uname ));
//                                                                                            ArrayList<CustomerDetail> AL1 = (ArrayList<CustomerDetail>) cr1.list();
//                                                                                            String CNAME=AL1.get(0).getCName();

                        
                        Criteria cr2 = se.createCriteria(D.Offer.class);
//                                                                                            cr1.add(Restrictions.eq("cname",CNAME ));
                        ArrayList<Offer> AL2 = (ArrayList<Offer>) cr2.list();
//                        ArrayList<String> fmsg =new ArrayList<String>();
//                                for(int j=0;j<=AL2.size();j++)
//                                {
//                                String Date=AL2.get(j).getDate();
//                                int Discount=AL2.get(j).getDiscount();
//                                int Mil=AL2.get(j).getMileage();
//                                int price =   AL2.get(j).getPrice();
//                                String Fback= " Offer on "+Date+ " for discount of " + Discount+ " for mileage "+ Mil+ "at price "+ price;
//                                fmsg.add(Fback);
//                                }
                                ss.setAttribute("Feed", AL2);
                        RequestDispatcher rs=request.getRequestDispatcher("getAchvment");
                        rs.forward(request, response);
                        }
                    
                        
                        
                        
                        
                        
                        
            }
            
        t.commit();
        }
        catch(Exception e)
        {
            out.println(e.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
