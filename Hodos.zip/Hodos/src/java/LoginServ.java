/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import D.CustomerDetail;
import D.Login;
import D.RegCompanyDetail;
import D.ServiceDetail;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author KULDEEP
 */
public class LoginServ extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            Session se = NewHibernateUtil.getSessionFactory().openSession();
            Transaction t = se.beginTransaction();
            HttpSession ss=request.getSession();

            String Email = request.getParameter("Email");
            ss.setAttribute("email", Email);                
            String password = request.getParameter("password");
            Criteria cr = se.createCriteria(D.Login.class);
            cr.add(Restrictions.eq("email", Email));
            cr.add(Restrictions.eq("password", password));
            String msg = "";
              Cookie ck=new Cookie("name",Email); 
            ArrayList<Login> AL = (ArrayList<Login>) cr.list();
            if (AL.isEmpty()) {
                msg = "login fail!please try again";
                request.setAttribute("msg", msg);
                RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
                rd.forward(request, response);
                
            } 
          
            else if (AL.size() > 0) {
                
                Login L = AL.get(0);
                String Role = L.getRole();
                if ("Customer".equals(Role)) {
                    Criteria crt = se.createCriteria(CustomerDetail.class);
                    crt.add(Restrictions.eq("lid",L));
                    ArrayList<CustomerDetail> AL1 = (ArrayList<CustomerDetail>) crt.list();
                    msg=  AL1.get(0).getName();
                    
                    t.commit();
                   
                        ss.setAttribute("UNAME", msg);
                    RequestDispatcher rd = request.getRequestDispatcher("getOfferServ");
                    rd.forward(request, response);
                }  if("service".equals(Role)) {
                    Criteria crt = se.createCriteria(ServiceDetail.class);
                    crt.add(Restrictions.eq("lid",L));
                    ArrayList<ServiceDetail> AL1 = (ArrayList<ServiceDetail>) crt.list();
                    msg=  AL1.get(0).getName();
                    t.commit();
                   
                    ss.setAttribute("UNAME", msg);
                    RequestDispatcher rd = request.getRequestDispatcher("getAchvment");
                    rd.forward(request, response);

                }
                 if("Company".equals(Role)) {
                    Criteria crt = se.createCriteria(RegCompanyDetail.class);
                    crt.add(Restrictions.eq("lid",L));
                    ArrayList<RegCompanyDetail> AL1 = (ArrayList<RegCompanyDetail>) crt.list();
                    msg=  AL1.get(0).getName();
                    t.commit();

                     ss.setAttribute("UNAME", msg);
                     RequestDispatcher rd = request.getRequestDispatcher("getAchvment");
                     rd.forward(request, response);

                }
            }

            
        } catch(ServletException Ex) {

            out.println(Ex.getMessage());

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
