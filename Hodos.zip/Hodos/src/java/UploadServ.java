/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.hibernate.Session;
import org.hibernate.Transaction;
import D.Imagedata;
import D.Login;
/**
 *
 * @author KULDEEP
 */
public class UploadServ extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
        protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession hs = request.getSession();
        ArrayList<String> al = new ArrayList<>();
        try (PrintWriter out = response.getWriter()) {
           
            String photo = "1";
            String pname=hs.getAttribute("CName").toString();
            //create new folder at given path
            String dirname = "image";
            File dir = new File("C:\\Users\\KULDEEP\\Documents\\NetBeansProjects\\Hodos\\web\\" + dirname + "\\");
            dir.mkdir();
//             
//             boolean isMultipartContent = ServletFileUpload.isMultipartContent(request);
//             
//             
//            if (!isMultipartContent) 
//            {
//                    out.println("You are not trying to upload<br>");
//                    return;
//            }

            // creates FileItem instances which keep their content in a temporary file on disk
            FileItemFactory factory = new DiskFileItemFactory();
            // Create a new file upload handler
            ServletFileUpload upload = new ServletFileUpload(factory);

            //get the list of all fields from request
            List<FileItem> fields = upload.parseRequest(request);
            // iterates the object of list
            Iterator<FileItem> it = fields.iterator();
            //getting objects one by one
            while (it.hasNext()) {
                //assigning coming object if list to object of FileItem
                FileItem fileItem = it.next();
                //check whether field is form field or not
               boolean isFormField = fileItem.isFormField();

                if (isFormField) {
                    //get the filed name 
                    String fieldName = fileItem.getFieldName();
                    if (fieldName.equals("pname")) {
                        //getting value of field
                       pname = fileItem.getString();
                    }
                }
     else {
                    //getting name of file
                    photo = new File(fileItem.getName()).getName();
                    //get the extension of file by diving name into substring
                    String extension = photo.substring(photo.indexOf(".") + 1, photo.length());;
                    //rename file...concate name and extension
                    photo = pname + "." + extension;
                    //add multiple images into arraylist
                    al.add(photo);
                    try {
                        String filePath = "C:\\Users\\KULDEEP\\Documents\\NetBeansProjects\\Hodos\\web\\" + dirname + "\\";
                        fileItem.write(new File(filePath + photo));
                    } catch (Exception ex) {
                        out.println(ex.toString());
                    }

                }

            }

//             hs.setAttribute("photo", photo);
           Session s = NewHibernateUtil.getSessionFactory().openSession();
            Transaction t = s.beginTransaction();
             //create for loop for add multiple images in database
           // for (int i = 0; i < =al.size(); i++) {
                Imagedata im = new Imagedata();
               im.setCName(pname);
               im.setIurl(photo);
               Login L=(Login) hs.getAttribute("L");
               im.setLid(L);
                s.save(im);

            //}
            t.commit();
            
//             Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=TestDB","sa","drashti123");
//            PreparedStatement ps;
//            //RequstDispatcher rd = null;
////            HttpSession sess=request.getSession();
//       
////        String uid=(String)sess.getAttribute("uid");
////            String name=request.getParameter("name");
//            ps = con.prepareStatement("insert into Image_data values(?,?)");
//            ps.setString(1,pname);
//            ps.setString(2,photo);
//             ps.executeUpdate();
        
          String  msg = "Registered successfully.Please login to continue.";
          request.setAttribute("msg", msg);
                
            RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
          rd.forward(request, response);
//            response.sendRedirect("viewserv");

        } catch (Exception ex) {
            out.println(ex.getMessage());
        } finally {
            out.close();
        }

    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
