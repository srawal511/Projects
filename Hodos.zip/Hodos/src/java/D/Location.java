/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package D;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author KULDEEP
 */
@Entity
@Table(name = "Location")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Location.findAll", query = "SELECT l FROM Location l"),
    @NamedQuery(name = "Location.findByLLid", query = "SELECT l FROM Location l WHERE l.lLid = :lLid"),
    @NamedQuery(name = "Location.findByLat", query = "SELECT l FROM Location l WHERE l.lat = :lat"),
    @NamedQuery(name = "Location.findByLong1", query = "SELECT l FROM Location l WHERE l.long1 = :long1")})
public class Location implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id@GeneratedValue
    @Basic(optional = false)
    @Column(name = "LLid")
    private Integer lLid;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "lat")
    private Double lat;
    @Column(name = "long")
    private Double long1;
    @JoinColumn(name = "lid", referencedColumnName = "Lid")
    @ManyToOne(optional = false)
    private Login lid;

    public Location() {
    }

    public Location(Integer lLid) {
        this.lLid = lLid;
    }

    public Integer getLLid() {
        return lLid;
    }

    public void setLLid(Integer lLid) {
        this.lLid = lLid;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLong1() {
        return long1;
    }

    public void setLong1(Double long1) {
        this.long1 = long1;
    }

    public Login getLid() {
        return lid;
    }

    public void setLid(Login lid) {
        this.lid = lid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (lLid != null ? lLid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Location)) {
            return false;
        }
        Location other = (Location) object;
        if ((this.lLid == null && other.lLid != null) || (this.lLid != null && !this.lLid.equals(other.lLid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "D.Location[ lLid=" + lLid + " ]";
    }
    
}
