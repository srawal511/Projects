/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package D;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author KULDEEP
 */
@Entity
@Table(name = "Achievements")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Achievements.findAll", query = "SELECT a FROM Achievements a"),
    @NamedQuery(name = "Achievements.findByAid", query = "SELECT a FROM Achievements a WHERE a.aid = :aid"),
    @NamedQuery(name = "Achievements.findByDate", query = "SELECT a FROM Achievements a WHERE a.date = :date"),
    @NamedQuery(name = "Achievements.findByTopic", query = "SELECT a FROM Achievements a WHERE a.topic = :topic"),
    @NamedQuery(name = "Achievements.findByDetails", query = "SELECT a FROM Achievements a WHERE a.details = :details"),
    @NamedQuery(name = "Achievements.findByCname", query = "SELECT a FROM Achievements a WHERE a.cname = :cname")})
public class Achievements implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id @GeneratedValue
    @Basic(optional = false)
    @Column(name = "Aid")
    private Integer aid;
    @Column(name = "Date")
    private String date;
    @Column(name = "Topic")
    private String topic;
    @Column(name = "Details")
    private String details;
    @Column(name = "Cname")
    private String cname;
    @JoinColumn(name = "Lid", referencedColumnName = "Lid")
    @ManyToOne(optional = false)
    private Login lid;

    public Achievements() {
    }

    public Achievements(Integer aid) {
        this.aid = aid;
    }

    public Integer getAid() {
        return aid;
    }

    public void setAid(Integer aid) {
        this.aid = aid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public Login getLid() {
        return lid;
    }

    public void setLid(Login lid) {
        this.lid = lid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (aid != null ? aid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Achievements)) {
            return false;
        }
        Achievements other = (Achievements) object;
        if ((this.aid == null && other.aid != null) || (this.aid != null && !this.aid.equals(other.aid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "D.Achievements[ aid=" + aid + " ]";
    }
    
}
