/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package D;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author KULDEEP
 */
@Entity
@Table(name = "Imagedata")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Imagedata.findAll", query = "SELECT i FROM Imagedata i"),
    @NamedQuery(name = "Imagedata.findByCName", query = "SELECT i FROM Imagedata i WHERE i.cName = :cName"),
    @NamedQuery(name = "Imagedata.findByIurl", query = "SELECT i FROM Imagedata i WHERE i.iurl = :iurl"),
    @NamedQuery(name = "Imagedata.findByIid", query = "SELECT i FROM Imagedata i WHERE i.iid = :iid")})
public class Imagedata implements Serializable {
    private static final long serialVersionUID = 1L;
    @Column(name = "CName")
    private String cName;
    @Column(name = "Iurl")
    private String iurl;
    @Id @GeneratedValue
    @Basic(optional = false)
    @Column(name = "IID")
    private Integer iid;
    @JoinColumn(name = "Lid", referencedColumnName = "Lid")
    @ManyToOne(optional = false)
    private Login lid;

    public Imagedata() {
    }

    public Imagedata(Integer iid) {
        this.iid = iid;
    }

    public String getCName() {
        return cName;
    }

    public void setCName(String cName) {
        this.cName = cName;
    }

    public String getIurl() {
        return iurl;
    }

    public void setIurl(String iurl) {
        this.iurl = iurl;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Login getLid() {
        return lid;
    }

    public void setLid(Login lid) {
        this.lid = lid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iid != null ? iid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Imagedata)) {
            return false;
        }
        Imagedata other = (Imagedata) object;
        if ((this.iid == null && other.iid != null) || (this.iid != null && !this.iid.equals(other.iid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "D.Imagedata[ iid=" + iid + " ]";
    }
    
}
