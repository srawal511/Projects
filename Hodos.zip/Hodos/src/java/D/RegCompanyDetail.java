/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package D;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author KULDEEP
 */
@Entity
@Table(name = "Reg_Company_Detail", catalog = "Reg2", schema = "dbo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "RegCompanyDetail.findAll", query = "SELECT r FROM RegCompanyDetail r"),
    @NamedQuery(name = "RegCompanyDetail.findByRid", query = "SELECT r FROM RegCompanyDetail r WHERE r.rid = :rid"),
    @NamedQuery(name = "RegCompanyDetail.findByName", query = "SELECT r FROM RegCompanyDetail r WHERE r.name = :name"),
    @NamedQuery(name = "RegCompanyDetail.findByContact", query = "SELECT r FROM RegCompanyDetail r WHERE r.contact = :contact"),
    @NamedQuery(name = "RegCompanyDetail.findByAddress", query = "SELECT r FROM RegCompanyDetail r WHERE r.address = :address"),
    @NamedQuery(name = "RegCompanyDetail.findByAdharcard", query = "SELECT r FROM RegCompanyDetail r WHERE r.adharcard = :adharcard"),
    @NamedQuery(name = "RegCompanyDetail.findByElectioncard", query = "SELECT r FROM RegCompanyDetail r WHERE r.electioncard = :electioncard"),
    @NamedQuery(name = "RegCompanyDetail.findBySince", query = "SELECT r FROM RegCompanyDetail r WHERE r.since = :since"),
    @NamedQuery(name = "RegCompanyDetail.findByCName", query = "SELECT r FROM RegCompanyDetail r WHERE r.cName = :cName")})
public class RegCompanyDetail implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id@GeneratedValue
    @Basic(optional = false)
    @Column(name = "Rid")
    private Integer rid;
    @Column(name = "Name")
    private String name;
    @Column(name = "Contact")
    private String contact;
    @Column(name = "Address")
    private String address;
    @Column(name = "Adhar_card")
    private String adharcard;
    @Column(name = "Election_card")
    private String electioncard;
    @Column(name = "Since")
    private String since;
    @Column(name = "CName")
    private String cName;
    @JoinColumn(name = "Lid", referencedColumnName = "Lid")
    @ManyToOne(optional = false)
    private Login lid;

    public RegCompanyDetail() {
    }

    public RegCompanyDetail(Integer rid) {
        this.rid = rid;
    }

    public Integer getRid() {
        return rid;
    }

    public void setRid(Integer rid) {
        this.rid = rid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAdharcard() {
        return adharcard;
    }

    public void setAdharcard(String adharcard) {
        this.adharcard = adharcard;
    }

    public String getElectioncard() {
        return electioncard;
    }

    public void setElectioncard(String electioncard) {
        this.electioncard = electioncard;
    }

    public String getSince() {
        return since;
    }

    public void setSince(String since) {
        this.since = since;
    }

    public String getCName() {
        return cName;   
    }

    public void setCName(String cName) {
        this.cName = cName;
    }

    public Login getLid() {
        return lid;
    }

    public void setLid(Login lid) {
        this.lid = lid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (rid != null ? rid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RegCompanyDetail)) {
            return false;
        }
        RegCompanyDetail other = (RegCompanyDetail) object;
        if ((this.rid == null && other.rid != null) || (this.rid != null && !this.rid.equals(other.rid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "D.RegCompanyDetail[ rid=" + rid + " ]";
    }
    
}
