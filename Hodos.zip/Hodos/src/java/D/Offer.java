/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package D;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author KULDEEP
 */
@Entity
@Table(name = "Offer")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Offer.findAll", query = "SELECT o FROM Offer o"),
    @NamedQuery(name = "Offer.findByOid", query = "SELECT o FROM Offer o WHERE o.oid = :oid"),
    @NamedQuery(name = "Offer.findByCname", query = "SELECT o FROM Offer o WHERE o.cname = :cname"),
    @NamedQuery(name = "Offer.findByDate", query = "SELECT o FROM Offer o WHERE o.date = :date"),
    @NamedQuery(name = "Offer.findByMileage", query = "SELECT o FROM Offer o WHERE o.mileage = :mileage"),
    @NamedQuery(name = "Offer.findByDiscount", query = "SELECT o FROM Offer o WHERE o.discount = :discount"),
    @NamedQuery(name = "Offer.findByPrice", query = "SELECT o FROM Offer o WHERE o.price = :price")})
public class Offer implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id@GeneratedValue
    @Basic(optional = false)
    @Column(name = "Oid")
    private Integer oid;
    @Basic(optional = false)
    @Column(name = "Cname")
    private String cname;
    @Column(name = "Date")
    private String date;
    @Column(name = "Mileage")
    private Integer mileage;
    @Column(name = "Discount")
    private Integer discount;
    @Column(name = "Price")
    private Integer price;
    @JoinColumn(name = "Lid", referencedColumnName = "Lid")
    @ManyToOne(optional = false)
    private Login lid;

    public Offer() {
    }

    public Offer(Integer oid) {
        this.oid = oid;
    }

    public Offer(Integer oid, String cname) {
        this.oid = oid;
        this.cname = cname;
    }

    public Integer getOid() {
        return oid;
    }

    public void setOid(Integer oid) {
        this.oid = oid;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getMileage() {
        return mileage;
    }

    public void setMileage(Integer mileage) {
        this.mileage = mileage;
    }

    public Integer getDiscount() {
        return discount;
    }

    public void setDiscount(Integer discount) {
        this.discount = discount;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Login getLid() {
        return lid;
    }

    public void setLid(Login lid) {
        this.lid = lid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (oid != null ? oid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Offer)) {
            return false;
        }
        Offer other = (Offer) object;
        if ((this.oid == null && other.oid != null) || (this.oid != null && !this.oid.equals(other.oid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "D.Offer[ oid=" + oid + " ]";
    }
    
}
