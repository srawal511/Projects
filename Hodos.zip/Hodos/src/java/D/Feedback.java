/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package D;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author KULDEEP
 */
@Entity
@Table(name = "Feedback")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Feedback.findAll", query = "SELECT f FROM Feedback f"),
    @NamedQuery(name = "Feedback.findByFid", query = "SELECT f FROM Feedback f WHERE f.fid = :fid"),
    @NamedQuery(name = "Feedback.findByFeedbackFor", query = "SELECT f FROM Feedback f WHERE f.feedbackFor = :feedbackFor"),
    @NamedQuery(name = "Feedback.findByFmsg", query = "SELECT f FROM Feedback f WHERE f.fmsg = :fmsg"),
    @NamedQuery(name = "Feedback.findByEmail", query = "SELECT f FROM Feedback f WHERE f.email = :email"),
    @NamedQuery(name = "Feedback.findByRole", query = "SELECT f FROM Feedback f WHERE f.role = :role"),
    @NamedQuery(name = "Feedback.findByDate", query = "SELECT f FROM Feedback f WHERE f.date = :date"),
    @NamedQuery(name = "Feedback.findByPlace", query = "SELECT f FROM Feedback f WHERE f.place = :place"),
    @NamedQuery(name = "Feedback.findByStar", query = "SELECT f FROM Feedback f WHERE f.star = :star")})
public class Feedback implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue
    @Basic(optional = false)
    @Column(name = "Fid")
    private Integer fid;
    @Basic(optional = false)
    @Column(name = "FeedbackFor")
    private String feedbackFor;
    @Basic(optional = false)
    @Column(name = "Fmsg")
    private String fmsg;
    @Column(name = "Email")
    private String email;
    @Column(name = "Role")
    private String role;
    @Column(name = "Date")
    private String date;
    @Column(name = "Place")
    private String place;
    @Column(name = "Star")
    private Integer star;
    @JoinColumn(name = "Lid", referencedColumnName = "Lid")
    @ManyToOne(optional = false)
    private Login lid;

    public Feedback() {
    }

    public Feedback(Integer fid) {
        this.fid = fid;
    }

    public Feedback(Integer fid, String feedbackFor, String fmsg) {
        this.fid = fid;
        this.feedbackFor = feedbackFor;
        this.fmsg = fmsg;
    }

    public Integer getFid() {
        return fid;
    }

    public void setFid(Integer fid) {
        this.fid = fid;
    }

    public String getFeedbackFor() {
        return feedbackFor;
    }

    public void setFeedbackFor(String feedbackFor) {
        this.feedbackFor = feedbackFor;
    }

    public String getFmsg() {
        return fmsg;
    }

    public void setFmsg(String fmsg) {
        this.fmsg = fmsg;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public Integer getStar() {
        return star;
    }

    public void setStar(Integer star) {
        this.star = star;
    }

    public Login getLid() {
        return lid;
    }

    public void setLid(Login lid) {
        this.lid = lid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (fid != null ? fid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Feedback)) {
            return false;
        }
        Feedback other = (Feedback) object;
        if ((this.fid == null && other.fid != null) || (this.fid != null && !this.fid.equals(other.fid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "D.Feedback[ fid=" + fid + " ]";
    }

    public void getStar(String toString) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
