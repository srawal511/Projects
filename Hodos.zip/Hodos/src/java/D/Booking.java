/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package D;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author KULDEEP
 */
@Entity
@Table(name = "Booking")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Booking.findAll", query = "SELECT b FROM Booking b"),
    @NamedQuery(name = "Booking.findByBid", query = "SELECT b FROM Booking b WHERE b.bid = :bid"),
    @NamedQuery(name = "Booking.findByPickup", query = "SELECT b FROM Booking b WHERE b.pickup = :pickup"),
    @NamedQuery(name = "Booking.findByDropup", query = "SELECT b FROM Booking b WHERE b.dropup = :dropup"),
    @NamedQuery(name = "Booking.findByPDate", query = "SELECT b FROM Booking b WHERE b.pDate = :pDate"),
    @NamedQuery(name = "Booking.findByDDate", query = "SELECT b FROM Booking b WHERE b.dDate = :dDate"),
    @NamedQuery(name = "Booking.findByPTime", query = "SELECT b FROM Booking b WHERE b.pTime = :pTime"),
    @NamedQuery(name = "Booking.findByDTime", query = "SELECT b FROM Booking b WHERE b.dTime = :dTime"),
    @NamedQuery(name = "Booking.findByReason", query = "SELECT b FROM Booking b WHERE b.reason = :reason"),
    @NamedQuery(name = "Booking.findByCName", query = "SELECT b FROM Booking b WHERE b.cName = :cName"),
    @NamedQuery(name = "Booking.findByNumber", query = "SELECT b FROM Booking b WHERE b.number = :number"),
    @NamedQuery(name = "Booking.findByPlace", query = "SELECT b FROM Booking b WHERE b.place = :place")})
public class Booking implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id @GeneratedValue
    @Basic(optional = false)
    @Column(name = "Bid")
    private Integer bid;
    @Column(name = "Pickup")
    private String pickup;
    @Column(name = "Dropup")
    private String dropup;
    @Column(name = "PDate")
    private String pDate;
    @Column(name = "DDate")
    private String dDate;
    @Column(name = "PTime")
    private String pTime;
    @Column(name = "DTime")
    private String dTime;
    @Column(name = "Reason")
    private String reason;
    @Column(name = "CName")
    private String cName;
    @Column(name = "Number")
    private String number;
    @Column(name = "place")
    private String place;
    @JoinColumn(name = "Lid", referencedColumnName = "Lid")
    @ManyToOne(optional = false)
    private Login lid;

    public Booking() {
    }

    public Booking(Integer bid) {
        this.bid = bid;
    }

    public Integer getBid() {
        return bid;
    }

    public void setBid(Integer bid) {
        this.bid = bid;
    }

    public String getPickup() {
        return pickup;
    }

    public void setPickup(String pickup) {
        this.pickup = pickup;
    }

    public String getDropup() {
        return dropup;
    }

    public void setDropup(String dropup) {
        this.dropup = dropup;
    }

    public String getPDate() {
        return pDate;
    }

    public void setPDate(String pDate) {
        this.pDate = pDate;
    }

    public String getDDate() {
        return dDate;
    }

    public void setDDate(String dDate) {
        this.dDate = dDate;
    }

    public String getPTime() {
        return pTime;
    }

    public void setPTime(String pTime) {
        this.pTime = pTime;
    }

    public String getDTime() {
        return dTime;
    }

    public void setDTime(String dTime) {
        this.dTime = dTime;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getCName() {
        return cName;
    }

    public void setCName(String cName) {
        this.cName = cName;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public Login getLid() {
        return lid;
    }

    public void setLid(Login lid) {
        this.lid = lid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bid != null ? bid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Booking)) {
            return false;
        }
        Booking other = (Booking) object;
        if ((this.bid == null && other.bid != null) || (this.bid != null && !this.bid.equals(other.bid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "D.Booking[ bid=" + bid + " ]";
    }
    
}
