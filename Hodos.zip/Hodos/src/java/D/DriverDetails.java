/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package D;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author KULDEEP
 */
@Entity
@Table(name = "DriverDetails")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DriverDetails.findAll", query = "SELECT d FROM DriverDetails d"),
    @NamedQuery(name = "DriverDetails.findByDid", query = "SELECT d FROM DriverDetails d WHERE d.did = :did"),
    @NamedQuery(name = "DriverDetails.findByDate", query = "SELECT d FROM DriverDetails d WHERE d.date = :date"),
    @NamedQuery(name = "DriverDetails.findByDname", query = "SELECT d FROM DriverDetails d WHERE d.dname = :dname"),
    @NamedQuery(name = "DriverDetails.findByExperince", query = "SELECT d FROM DriverDetails d WHERE d.experince = :experince"),
    @NamedQuery(name = "DriverDetails.findByAge", query = "SELECT d FROM DriverDetails d WHERE d.age = :age"),
    @NamedQuery(name = "DriverDetails.findByCname", query = "SELECT d FROM DriverDetails d WHERE d.cname = :cname"),
    @NamedQuery(name = "DriverDetails.findByPhone", query = "SELECT d FROM DriverDetails d WHERE d.phone = :phone"),
    @NamedQuery(name = "DriverDetails.findByPlace", query = "SELECT d FROM DriverDetails d WHERE d.place = :place")})
public class DriverDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id@GeneratedValue
    @Basic(optional = false)
    @Column(name = "Did")
    private Integer did;
    @Column(name = "Date")
    private String date;
    @Column(name = "Dname")
    private String dname;
    @Column(name = "Experince")
    private Integer experince;
    @Column(name = "Age")
    private Integer age;
    @Column(name = "Cname")
    private String cname;
    @Column(name = "Phone")
    private Integer phone;
    @Column(name = "Place")
    private String place;
    @JoinColumn(name = "Lid", referencedColumnName = "Lid")
    @ManyToOne(optional = false)
    private Login lid;

    public DriverDetails() {
    }

    public DriverDetails(Integer did) {
        this.did = did;
    }

    public Integer getDid() {
        return did;
    }

    public void setDid(Integer did) {
        this.did = did;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public Integer getExperince() {
        return experince;
    }

    public void setExperince(Integer experince) {
        this.experince = experince;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public Integer getPhone() {
        return phone;
    }

    public void setPhone(Integer phone) {
        this.phone = phone;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public Login getLid() {
        return lid;
    }

    public void setLid(Login lid) {
        this.lid = lid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (did != null ? did.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DriverDetails)) {
            return false;
        }
        DriverDetails other = (DriverDetails) object;
        if ((this.did == null && other.did != null) || (this.did != null && !this.did.equals(other.did))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "D.DriverDetails[ did=" + did + " ]";
    }
    
}
