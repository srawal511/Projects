/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package D;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author KULDEEP
 */
@Entity
@Table(name = "Service_Detail", catalog = "Reg2", schema = "dbo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ServiceDetail.findAll", query = "SELECT s FROM ServiceDetail s"),
    @NamedQuery(name = "ServiceDetail.findBySid", query = "SELECT s FROM ServiceDetail s WHERE s.sid = :sid"),
    @NamedQuery(name = "ServiceDetail.findByName", query = "SELECT s FROM ServiceDetail s WHERE s.name = :name"),
    @NamedQuery(name = "ServiceDetail.findByContact", query = "SELECT s FROM ServiceDetail s WHERE s.contact = :contact"),
    @NamedQuery(name = "ServiceDetail.findByAddress", query = "SELECT s FROM ServiceDetail s WHERE s.address = :address"),
    @NamedQuery(name = "ServiceDetail.findByAdharcard", query = "SELECT s FROM ServiceDetail s WHERE s.adharcard = :adharcard"),
    @NamedQuery(name = "ServiceDetail.findByElectioncard", query = "SELECT s FROM ServiceDetail s WHERE s.electioncard = :electioncard"),
    @NamedQuery(name = "ServiceDetail.findBySince", query = "SELECT s FROM ServiceDetail s WHERE s.since = :since"),
    @NamedQuery(name = "ServiceDetail.findByCName", query = "SELECT s FROM ServiceDetail s WHERE s.cName = :cName")})
public class ServiceDetail implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id@GeneratedValue
    @Basic(optional = false)
    @Column(name = "Sid")
    private Integer sid;
    @Column(name = "Name")
    private String name;
    @Column(name = "Contact")
    private String contact;
    @Column(name = "Address")
    private String address;
    @Column(name = "Adhar_card")
    private String adharcard;
    @Column(name = "Election_card")
    private String electioncard;
    @Column(name = "Since")
    private String since;
    @Column(name = "CName")
    private String cName;
    @JoinColumn(name = "Lid", referencedColumnName = "Lid")
    @ManyToOne(optional = false)
    private Login lid;

    public ServiceDetail() {
    }

    public ServiceDetail(Integer sid) {
        this.sid = sid;
    }

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAdharcard() {
        return adharcard;
    }

    public void setAdharcard(String adharcard) {
        this.adharcard = adharcard;
    }

    public String getElectioncard() {
        return electioncard;
    }

    public void setElectioncard(String electioncard) {
        this.electioncard = electioncard;
    }

    public String getSince() {
        return since;
    }

    public void setSince(String since) {
        this.since = since;
    }

    public String getCName() {
        return cName;
    }

    public void setCName(String cName) {
        this.cName = cName;
    }

    public Login getLid() {
        return lid;
    }

    public void setLid(Login lid) {
        this.lid = lid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sid != null ? sid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ServiceDetail)) {
            return false;
        }
        ServiceDetail other = (ServiceDetail) object;
        if ((this.sid == null && other.sid != null) || (this.sid != null && !this.sid.equals(other.sid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "D.ServiceDetail[ sid=" + sid + " ]";
    }
    
}
