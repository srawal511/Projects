/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package D;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author KULDEEP
 */
@Entity
@Table(name = "Admin_Detail", catalog = "Reg2", schema = "dbo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "AdminDetail.findAll", query = "SELECT a FROM AdminDetail a"),
    @NamedQuery(name = "AdminDetail.findByAid", query = "SELECT a FROM AdminDetail a WHERE a.aid = :aid"),
    @NamedQuery(name = "AdminDetail.findByName", query = "SELECT a FROM AdminDetail a WHERE a.name = :name"),
    @NamedQuery(name = "AdminDetail.findByGender", query = "SELECT a FROM AdminDetail a WHERE a.gender = :gender"),
    @NamedQuery(name = "AdminDetail.findByContact", query = "SELECT a FROM AdminDetail a WHERE a.contact = :contact")})
public class AdminDetail implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id@GeneratedValue
    @Basic(optional = false)
    @Column(name = "Aid")
    private Integer aid;
    @Basic(optional = false)
    @Column(name = "Name")
    private String name;
    @Basic(optional = false)
    @Column(name = "Gender")
    private String gender;
    @Basic(optional = false)
    @Column(name = "Contact")
    private String contact;
    @JoinColumn(name = "Lid", referencedColumnName = "Lid")
    @ManyToOne(optional = false)
    private Login lid;

    public AdminDetail() {
    }

    public AdminDetail(Integer aid) {
        this.aid = aid;
    }

    public AdminDetail(Integer aid, String name, String gender, String contact) {
        this.aid = aid;
        this.name = name;
        this.gender = gender;
        this.contact = contact;
    }

    public Integer getAid() {
        return aid;
    }

    public void setAid(Integer aid) {
        this.aid = aid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public Login getLid() {
        return lid;
    }

    public void setLid(Login lid) {
        this.lid = lid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (aid != null ? aid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AdminDetail)) {
            return false;
        }
        AdminDetail other = (AdminDetail) object;
        if ((this.aid == null && other.aid != null) || (this.aid != null && !this.aid.equals(other.aid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "D.AdminDetail[ aid=" + aid + " ]";
    }
    
}
