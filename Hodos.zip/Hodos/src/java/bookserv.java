/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import D.Booking;
import D.CustomerDetail;
import D.Login;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author KULDEEP
 */
public class bookserv extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try
        {
            Session se=NewHibernateUtil.getSessionFactory().openSession();
            Transaction t=se.beginTransaction();
                String Cname=request.getParameter("Cname");
                String Ploc=request.getParameter("Ploc");
                String Dloc=request.getParameter("Dloc");
                String D1=request.getParameter("D1");
                String D2=request.getParameter("D2");
                String T1=request.getParameter("T1");
                String T2=request.getParameter("T2");
                String Reason=request.getParameter("Reason");
                String Number=request.getParameter("Number");
               String place =request.getParameter("city");
                HttpSession ss=request.getSession();
            
                String UNAME= ss.getAttribute("UNAME").toString();
                Criteria cr=se.createCriteria(CustomerDetail.class);
                cr.add(Restrictions.eq("name", UNAME));
                ArrayList<CustomerDetail> lr= (ArrayList<CustomerDetail>)cr.list();
                                Login LL= lr.get(0).getLid();
                    ArrayList<String> Cont=new ArrayList<String>();
            Cont.add(Cname);
            Cont.add(Ploc);
            Cont.add(Dloc);
            Cont.add(D1);
            Cont.add(D2);
            Cont.add(T1);
            Cont.add(T2);
            Cont.add(Reason);
            Cont.add(Number);
            Cont.add(Ploc);
            Cont.add(LL.toString());
            
            
                
                    
                
                
                
            Booking B=new Booking();
            B.setCName(Cname);
            B.setDDate(D2);
            B.setPDate(D1);
            B.setPTime(T1);
            B.setDTime(T2);
            B.setPickup(Ploc);
            B.setDropup(Dloc);
            B.setReason(Reason);
            B.setNumber(Number);
            B.setPlace(Ploc);
            B.setLid(LL);
            se.save(B);
            t.commit();
             ArrayList<Booking> Cont1=new ArrayList<Booking>();
             Cont1.add(B);
            ss.setAttribute("cont", Cont1);
            ss.setAttribute("place", Ploc);
                
          RequestDispatcher rd = request.getRequestDispatcher("SendBookingServ");
            rd.forward(request, response);           
             
               
        
        }
        catch( Exception ex)
        {
        out.println(ex.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
