/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import D.Feedback;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;

/**
 *
 * @author KULDEEP
 */
public class Topserv extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            Session se = NewHibernateUtil.getSessionFactory().openSession();
            Transaction t = se.beginTransaction();
            HttpSession ss = request.getSession();
            ArrayList<Feedback> al=new ArrayList<>();
            SQLQuery sql=se.createSQLQuery("select AVG(f.Star),f.FeedbackFor from Feedback as f join Login as l on f.Lid=l.Lid  group by f.FeedbackFor");
            
            List<Object[]> l= sql.list();
            
            for(Object[] o:l){
                Feedback f=new Feedback();
                f.setStar(o[0].hashCode());
                f.setFeedbackFor(o[1].toString());
                
                al.add(f);
            
            }
            /////////
//            int index =0;
//           int largestStar=al.get(0).getStar();
//           for(int i=0;i<al.size();i++)
//           {
//                    if(al.get(i).getStar()>largestStar)
//                    {
//                    largestStar=al.get(i).getStar();
//                    index=i;
//                    }
//                    
//                    if(al.get(i).getStar()!=lar)
//                    {
//                    
//                    
//                    }
//
//           
//           }
//            
              int count = 0;
            for (int outer = 0; outer < al.size(); outer++)
               {
                for (int inner = 1; inner < al.size()-outer; inner++)
                {
                  if (al.get(inner-1).getStar()< al.get(inner).getStar())
                  {
                      Feedback temp = al.get(inner-1);
                     al.set(inner-1, al.get(inner));
                      al.set(inner, temp);
                    count = count + 1;
                  }
                }
              }
//              for (int i = 0; i < al.size(); i++) {
//                  out.println( al.get(i).getStar());
//                  out.println("  "+al.get(i).getFeedbackFor());
//                    out.println(" </br> ");
//              }
//              
            
            
            
            
            

            ss.setAttribute("al", al);
         RequestDispatcher rd=request.getRequestDispatcher("Rank.jsp");
            rd.forward(request, response);
        
        } catch (Exception e) {
            out.println(e.getMessage());

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
